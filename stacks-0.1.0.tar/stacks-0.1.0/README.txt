See ``doc/index.txt`` for information.
