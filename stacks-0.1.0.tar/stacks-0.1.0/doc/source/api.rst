API Documentation
+++++++++++++++++
   
.. automodule:: stacks 
   :members:
   :undoc-members:
